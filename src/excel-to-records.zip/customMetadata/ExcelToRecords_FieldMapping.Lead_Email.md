<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Lead.email</label>
    <protected>false</protected>
    <values>
        <field>ExcelColumn__c</field>
        <value xsi:type="xsd:string">email</value>
    </values>
    <values>
        <field>Object__c</field>
        <value xsi:type="xsd:string">Lead</value>
    </values>
    <values>
        <field>SalesforceField__c</field>
        <value xsi:type="xsd:string">Email</value>
    </values>
</CustomMetadata>
